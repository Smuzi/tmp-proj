
Source: 
http://stackoverflow.com/questions/2428092/creating-a-json-response-using-django-and-python
http://stackoverflow.com/questions/8801084/how-to-calculate-next-friday-in-python