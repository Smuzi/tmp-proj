# CourseInfo
This folder contains the course data we get using [ScottyLabs/course-api](https://github.com/ScottyLabs/course-api). We parsed the data and generated the JSON files that we can load as initial data into our database.

## Files
> `CourseDescriptions.json` -- Course descriptions get from [ScottyLabs/course-api](https://github.com/ScottyLabs/course-api).  
> `SpringSchedule.json` -- Schedule for the spring semester get from [ScottyLabs/course-api](https://github.com/ScottyLabs/course-api).  
> `FallSchedule.json` -- Schedule for the fall semester get from [ScottyLabs/course-api](https://github.com/ScottyLabs/course-api).  
> `M1Schedule.json` --  Schedule for the mini 1 semester get from [ScottyLabs/course-api](https://github.com/ScottyLabs/course-api).  
> `M2Schedule.json` --  Schedule for the mini 2 semester get from [ScottyLabs/course-api](https://github.com/ScottyLabs/course-api).  
> `mercury_init_data1.json` -- Initial data for the spring semester.  
> `mercury_init_data2.json` -- Initial data for the fall semester.
> `mercury_init_data3.json` -- Initial data for the mini 1 semester.  
> `mercury_init_data4.json` -- Initial data for the mini 2 semester.  
> `parse.py` -- The parsing script that convert the JSON file we get from course-api to the data we can use for Mercury.

## How to load data
1. Copy all mercury_init_data*.json files to the folder webapps/mercury/fixtures
> `$ cp mercury_init_data*.json webapps/mercury/fixtures`

2. Switch to the webapps directory. 
> `$ cd webapps`

3. Load data.
> `$ python manage.py loaddata filename`


