import json

# search through CourseDescriptions.json, find the course
def findCourse(num):
	desc_file = open("CourseDescriptions.json", 'r')
	content = desc_file.read()
	parsed_content = json.loads(content)
	for course_desc in parsed_content:
		if course_desc["num"] == int(num):
			desc_file.close()
			return course_desc
	desc_file.close()
	return None

def generateInstructorJSON(index, name):
	index = index + 1
	new_instructor = {
		"model": "mercury.Instructor",
		"pk": index,
		"fields": {
			"name": name,
			"rating": 5.0
		}
	}
	return new_instructor

def generateRoomJSON(index, name):
	index = index + 1
	new_room = {
		"model": "mercury.Room",
		"pk": index,
		"fields": {
			"name": name,
			"rating": 5.0
		}
	}
	return new_room

# instructors: array of instructor-indexes. e.g. [1,2]
# room: index of a room
def generateMeetingJSON(index, instructors, begin, end, day, room, location):
	index = index + 1
	new_meeting = {
		"model": "mercury.Meeting",
		"pk": index,
		"fields": {
			"instructors": instructors,
			"begin": begin,
			"end": end,
			"day": day,
			"room": room,
			"location": location
		}
	}
	return new_meeting

# meetings: array of meeting-indexes
def generateSectionJSON(index, name, meetings):
	index = index + 1
	new_section = {
		"model": "mercury.Section",
		"pk": index,
		"fields": {
			"name": name,
			"meetings": meetings
		}
	}
	return new_section



def parseFile(file_name):
	global instructor_index
	global room_index
	global meeting_index
	global section_index

	global output_file
	global objects
	# Step 1: parse the schedule file, get the courses
	schedule_file = open(file_name, 'r')
	schedule_content = schedule_file.read()
	parsed_schedule = json.loads(schedule_content)

	for item in parsed_schedule:
		# item contains all courses from a department
		# print "======\nitem: %s\n" % (item)

		# dept stores current department
		dept = item['department']
		print "department: %s" % (dept)

		# parse each course
		for course in item['courses']:
			section_indexes = []
			for lec in course['lectures']:
				# no sections 
				#     -> treat each lecture as a Section
				if(len(lec["sections"]) == 0):
					ins_indexes = []
					meeting_indexes = []
					# create a section according to the lecture data
					# 1. create instructors
					for ins_name in lec["instructors"]:
						new_ins = generateInstructorJSON(instructor_index, ins_name)
						instructor_index += 1
						ins_indexes.append(instructor_index)
						objects.append(new_ins)
					# 2. create rooms and meetings
					for meeting in lec["meetings"]:
						# create room object
						new_room = generateRoomJSON(room_index, meeting["room"])
						room_index += 1
						objects.append(new_room)
						# create meeting object
						new_meeting = generateMeetingJSON(meeting_index, \
							ins_indexes, meeting["begin"], meeting["end"], \
							meeting["days"], room_index, meeting["location"])
						meeting_index += 1
						meeting_indexes.append(meeting_index)
						objects.append(new_meeting)
					# 3. create section
					new_section = generateSectionJSON(section_index, \
						lec["lecture"], meeting_indexes)
					section_index += 1
					section_indexes.append(section_index)
					objects.append(new_section)
				# multiple sections
				#     -> treat the combination of lec and 
				#        each section as a Section
				else:
					ins_indexes = []
					meeting_indexes = []
					# create sections according to the lecture data
					# 1. create instructors
					for ins_name in lec["instructors"]:
						new_ins = generateInstructorJSON(instructor_index, ins_name)
						instructor_index += 1
						ins_indexes.append(instructor_index)
						objects.append(new_ins)
					# 2. create rooms and meetings
					for meeting in lec["meetings"]:
						# create room object
						new_room = generateRoomJSON(room_index, meeting["room"])
						room_index += 1
						objects.append(new_room)
						# create meeting object
						new_meeting = generateMeetingJSON(meeting_index, \
							ins_indexes, meeting["begin"], meeting["end"], \
							meeting["days"], room_index, meeting["location"])
						meeting_index += 1
						meeting_indexes.append(meeting_index)
						objects.append(new_meeting)
					# 3. create sections
					for section in lec["sections"]:
						temp_ins_indexes = []
						temp_meeting_indexes = meeting_indexes
						# 3.1. create instructors
						for ins_name in section["instructors"]:
							new_ins = generateInstructorJSON(instructor_index, ins_name)
							instructor_index += 1
							temp_ins_indexes.append(instructor_index)
							objects.append(new_ins)
						# 3.2. create rooms and meetings
						for meeting in section["meetings"]:
							# create room object
							new_room = generateRoomJSON(room_index, meeting["room"])
							room_index += 1
							objects.append(new_room)
							# create meeting object
							new_meeting = generateMeetingJSON(meeting_index, \
								temp_ins_indexes, meeting["begin"], meeting["end"], \
								meeting["days"], room_index, meeting["location"])
							meeting_index += 1
							temp_meeting_indexes.append(meeting_index)
							objects.append(new_meeting)
						new_section = generateSectionJSON(section_index, \
							section["section"], temp_meeting_indexes)
						section_index += 1
						section_indexes.append(section_index)
						objects.append(new_section)
			
			num = course["num"]
			# print "course num: %s" % (num)
			# print "******\ncourse: %s" % (course)
			# find the course description
			desc = findCourse(num)
			# print "******\ncourse desc: %s\n" % (desc)
			# not found
			if(desc == None):
				# no description found: leave some fields blank 
				# print "no description for course %s" % (num)
				new_course = {
					"model": "mercury.Course",
					"pk": int(num),
					"fields": {
						"name": course["title"],
						"department": dept,
						"units": course["units"],
						"semester": None,
						"desc": None,
						"prereqs": None,
						"coreqs": None,
						"sections": section_indexes
					}
				}
				objects.append(new_course)
			# found the course description
			else:
				# generate the new json object
				new_course = {
					"model": "mercury.Course",
					"pk": int(num),
					"fields": {
						"name": desc["name"],
						"department": dept,
						"units": desc["units"],
						"semester": desc["semester"],
						"desc": desc["desc"],
						"prereqs": desc["prereqs"],
						"coreqs": desc["coreqs"],
						"sections": section_indexes
					}
				}
				objects.append(new_course)

instructor_index = 0
room_index = 0
meeting_index = 0
section_index = 0

objects = []
files = ["SpringSchedule.json", "FallSchedule.json", "M1Schedule.json", "M2Schedule.json"]

index = 0
for file_name in files:
	index += 1
	objects = []
	output_file = open("mercury_init_data"+ str(index) +".json", 'w')

	print "Start parse file: " + file_name
	parseFile(file_name)

	print "End of parsing"
	
	print "Start write data file: " + "mercury_init_data"+ str(index) +".json"
	output_file.write(json.dumps(objects))
	output_file.close()
	print "End of writing"
