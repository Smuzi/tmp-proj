from django.conf.urls import include, url

urlpatterns = [
    url(r'^$', 'mercury.views.home', name='home'),
    url(r'^login$', 'django.contrib.auth.views.login', {'template_name':'login.html'}, name='login'),
    url(r'^logout$', 'django.contrib.auth.views.logout_then_login', name='logout'),
    url(r'^register$', 'mercury.views.register', name='register'),
    url(r'^get_courses$', 'mercury.views.get_all_courses', name='get_all_courses'),
    url(r'^choose_course/(?P<course_id>\d+)$', 'mercury.views.choose_course'),
    url(r'^remove_choice/(?P<chosen_id>\d+)$', 'mercury.views.remove_choice'),
    url(r'^select_section/(?P<section_id>\d+)$', 'mercury.views.select_section_by_id'),
]
