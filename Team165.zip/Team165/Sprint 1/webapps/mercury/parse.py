from mercury.models import *
from mercury.forms import *
import json

def parseFile(filename):
	f = open(filename, 'r')
	content = f.read()
	# parsed_content={"courses":...., "fces":....}
	parsed_content = json.loads(content)
	# key = courses/fces
	for key in parsed_content:
		print "key: %s" % (key)
		# generate course objects from json file
		if key == "courses":
			i = 0;
			# id is the course id, value contains info of the course
			for id in parsed_content[key]:
				current_course = parsed_content[key][id]
				new_course = Course(id=id)
				new_course.name = current_course["name"]
				new_course.department = current_course["department"]
				new_course.units = current_course["units"]
				new_course.semester = current_course["semester"]
				new_course.desc = current_course["desc"]
				new_course.prereqs = current_course["prereqs"]
				new_course.coreqs = current_course["coreqs"]
				new_course.sections = Section(course=new_course)

				print new_course
				
				value = json.dumps(parsed_content[key][id])
				print "	id: %s, value: %s" % (id, value)
				for field in parsed_content[key][id]:
					print "	field: %s, value: %s \n" % (field, parsed_content[key][id][field])	
				break
				
			print i