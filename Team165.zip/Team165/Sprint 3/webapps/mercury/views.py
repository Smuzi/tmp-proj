from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.core.exceptions import ObjectDoesNotExist
from django.core import serializers
from django.http import HttpResponse
from django.db import transaction
import json
import datetime
from datetime import timedelta
import dateutil.parser as parser

# Decorator to use built-in authentication system
from django.contrib.auth.decorators import login_required

# Used to create and manually log in a user
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate

from mercury.models import *
from mercury.forms import *
from mercury.scheduler import *
from mercury.search import *
# Create your views here.

@login_required
def home(request):
    # Sets up list of just the logged-in user's (request.user's) items
    context = {}
    context['course_list'] = Course.objects.filter(department="Computer Science")
    student = Student.objects.get(user=request.user)
    context['schedule'] = Schedule.objects.get(owner=student)
	
    complete = {}
    last_option ={}
    conflict = {}

    user = request.user
    schedule = Schedule.objects.get(owner=student)
    #add conflicts to context:
    for course in schedule.courses.all():
        if is_course_complete(user,course):
            complete[course.name] = course.name
        elif is_course_conflicting(user,course):
            conflict[course.name] = course.name
        elif is_last_option(user,course):
            last_option[course.name] = course.name
	#color context: complete=green, conflict=red, last_option=yellow, normal=blue
    context['complete'] = complete
    context['last_option'] = last_option
    context['conflict'] = conflict

	#add last option and complete dict!!
    return render(request, 'index.html', context)

@transaction.atomic
def register(request):
    context = {}

    # Just display the registration form if this is a GET request.
    if request.method == 'GET':
        context['form'] = RegistrationForm()
        return render(request, 'register.html', context)

    # Creates a bound form from the request POST parameters and makes the 
    # form available in the request context dictionary.
    form = RegistrationForm(request.POST)
    context['form'] = form

    # Validates the form.
    if not form.is_valid():
        return render(request, 'register.html', context)

    # If we get here the form data was valid.  Register and login the user.
    new_user = User.objects.create_user(username=form.cleaned_data['username'], 
                                        password=form.cleaned_data['password1'])
    new_user.save()

    new_student = Student(user=new_user)
    new_student.save()

    new_schedule = Schedule(owner=new_student)
    new_schedule.save()

    # Logs in the new user and redirects to his/her schedule list
    new_user = authenticate(username=form.cleaned_data['username'], \
                            password=form.cleaned_data['password1'])
    login(request, new_user)
    return redirect('/mercury/')

def select_section_by_id(request,section_id):
	user = request.user
	section = Section.objects.get(pk=section_id)
	if is_section_covered(user,section):
		unselect_section(user,section)
	else:
		select_section(user,section)
	return redirect('/mercury/')
	
# when a user chooses a class from the dropdown menu list of all courses
# adds this course to the unselected list at the right
def choose_course(request, course_id):
    errors = []
    context = {}
    context = {'errors':errors}
    context['course_list'] = Course.objects.filter(department="Computer Science")
    try:
        student = Student.objects.get(user=request.user)
        schedule = Schedule.objects.get(owner=student)
        course = Course.objects.get(id=course_id)
        schedule.courses.add(course)
        
    except ObjectDoesNotExist:
        errors.append('That course does not exist.')

    context['schedule'] = schedule
    return render(request, 'index.html', context)

def remove_choice(request, chosen_id):
    errors = []
    context = {}
    context = {'errors':errors}
    context['course_list'] = Course.objects.filter(department="Computer Science")
    # Deletes the item if present in the course choice list.
    try:
        student = Student.objects.get(user=request.user)
        schedule = Schedule.objects.get(owner=student)
        choice_to_delete = Course.objects.get(id=chosen_id)
        schedule.courses.remove(choice_to_delete)
        for section in choice_to_delete.sections.all():
            unselect_section(request.user,section)
			
    except ObjectDoesNotExist:
        errors.append('That course wasn\'t in your schedule.')

    context['schedule'] = schedule
    return render(request, 'index.html', context)


# note: not done. not sure if needed
def toggle_available_meetings(request, chosen_id):
    errors = []
    context = {}
    context = {'errors':errors}
    context['course_list'] = Course.objects.filter(department="Computer Science")
    # Deletes the item if present in the todo-list database.
    try:
        student = Student.objects.get(user=request.user)
        schedule = Schedule.objects.get(owner=student)
        choice_to_draw = Course.objects.get(id=chosen_id)
        context["title"] = choice_to_draw.name

        
    except ObjectDoesNotExist:
        errors.append('That course wasn\'t in your schedule.')

    context['schedule'] = schedule
    return render(request, 'index.html', context)

# gets all of the courses that the user has selected on the right
#red - conflict
#blue - normal
#green - friend in meeting
def get_all_courses(request):
    user = request.user
    student = Student.objects.get(user=request.user)
    schedule = Schedule.objects.get(owner=student)
    # retrieves all the courses that the student has selected on the right.
    course_list = schedule.courses.all()
    event_list = []
    selected_meetings = schedule.meetings.all()
    friend_meetings = get_friends_meetings(request.user)
    # goes through each of these courses
	
    for course in course_list:
        if is_course_complete(user,course):
            courseFlag = True 
        else:
            courseFlag = False
        section_list = course.sections.all()
        for section in section_list:
            #set color based on whether there is a conflict or not
            color = "#d3d3d3"
            #if (is_section_conflicting(request.user, section) == True):
            #    color = "red"
            meeting_list = section.meetings.all()
            for meeting in meeting_list:
                displayFlag=False
                if (meeting in selected_meetings):
                    color = "blue"
                    displayFlag=True
                elif (courseFlag==False) and (meeting in friend_meetings):
                    color = "pink"
                    displayFlag=True
                elif (courseFlag==False):
                    displayFlag=True
                if displayFlag:
                    start = meeting.begin
                    end = meeting.end
                    if (meeting.day == "TBA"):
                        break
                    else:
                        for i in range(len(meeting.day)):
                    # weekday returns 0 for M, 1 for T, 2 for W...
                            dayName= ""
                            if (meeting.day[i] == "M"):
                                dayName = "Monday, "
                            if (meeting.day[i] == "T"): 
                                dayName = "Tuesday, "
                            if (meeting.day[i] == "W"): 
                                dayName = "Wednesday, "
                            if (meeting.day[i] == "R"): 
                                dayName = "Thursday, "
                            if (meeting.day[i] == "F"): 
                                dayName = "Friday, "
                            if (meeting.day[i] == "S"): 
                                dayName = "Saturday, "
                            if (meeting.day[i] == "U"): 
                                dayName = "Sunday, "

                        # create the class meeting event
                            temp_event = {
                                "title": course.name,
                                #"start": datetime.combine(d, meeting.begin).isoformat("T"),
                                "start": (parser.parse(dayName + str(start), fuzzy=True)).isoformat(),
                                "end": (parser.parse(dayName + str(end), fuzzy=True)).isoformat(),
                                "color": color,
                                "course_number": course.id,
                                "section_id": section.id,
                                "id": str(course.id) + section.name,
                                "section letter": section.name,
                                "meeting dot day": meeting.day,
                               # color needs to change based on whether something is selected or not
                               #"color": "#d3d3d3"
                            }
                            event_list.append(temp_event)
    return HttpResponse(json.dumps(event_list), content_type='application/json')

def course_search(request, search_text):
    if search_text is not None and search_text != u"":
        context = {}
        context['course_list'] = Course.objects.filter(name__contains = search_text)
        student = Student.objects.get(user=request.user)
        context['schedule'] = Schedule.objects.get(owner=student)
        return render(request, 'index.html', context)

#    if request.method == "GET":
#        search_text = request.GET['search_text']
#        if search_text is not None and search_text != u"":
#            search_text = request.GET['search_text']
#            found_courses = Course.objects.filter(name__contains = search_text)
#        else:
#            found_courses = []

#       return render(request, 'index.html', {'course_list':found_courses})


#source:http://julienphalip.com/post/2825034077/adding-search-to-a-django-site-in-a-snap
#backhand function in search.py
def search(request):
    query_string = ''
    found_entries = None
    if ('q' in request.GET) and request.GET['q'].strip():
        query_string = request.GET['q']
        
        entry_query = get_query(query_string, ['id', 'name',])
        
        found_entries = Course.objects.filter(entry_query).order_by('-id')
	
    found_courses = found_entries
    search_result = {}
    count = 0
    if not found_courses is None:
        for course in found_courses:
            search_result[course.id]=course.name
    return HttpResponse(json.dumps(search_result), content_type='application/json')
    #return render(request,'index.html',
    #                      { 'query_string': query_string, 'found_entries': found_entries })