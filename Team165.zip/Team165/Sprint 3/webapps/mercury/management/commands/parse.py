from django.core.management.base import BaseCommand
from mercury.models import *
import json

instructor_index = int(0)
room_index = int(0)
meeting_index = int(0)
section_index = int(0)

# objects = []
rooms = []
instructors = []
meetings = []
sections = []
courses = []

# search through CourseDescriptions.json, find the course
def findCourse(num):
	desc_file = open("./mercury/fixtures/CourseDescriptions.json", 'r')
	content = desc_file.read()
	parsed_content = json.loads(content)
	for course_desc in parsed_content:
		if course_desc["num"] == int(num):
			desc_file.close()
			return course_desc
	desc_file.close()
	return None

def saveInstructor(index, name):
	index = index + 1
	new_instructor = Instructor(id=int(index), name=name, rating=5.0)
	new_instructor.save()

def saveRoom(index, name):
	index = index + 1
	new_room = Room(id=int(index), name=name, rating=5.0)
	new_room.save()

def saveMeeting(index, instructors, begin, end, day, room, location):
	index = index + 1
	new_meeting = Meeting.objects.create(id=int(index), \
					begin=begin, \
					end=end, \
					day=day, \
					room_id=room, \
					location=location)
	for instr in instructors:
		new_meeting.instructors.add(instr)
	new_meeting.save()

def saveSection(index, name, meetings):
	index = index + 1
	new_section = Section.objects.create(id=int(index), \
					name=name)
	for meeting in meetings:
		m=Meeting.objects.get(id=meeting)
		new_section.meetings.add(m)
		new_section.save()

def saveCourse(num, name, department, units, semester, desc, prereqs, coreqs, sections):
	# limit the length of desc
	if desc is not None:
		unicode_desc = desc.encode("utf-8")
		# print len(unicode_desc)
		if(len(unicode_desc) > 1000):
			new_desc = desc[0:1000]
		else:
			new_desc = desc
	else:
		new_desc = None
	new_course = Course.objects.create(id=int(num), \
					name=name, \
					department=department, \
					units=units, \
					semester=semester, \
					desc=new_desc, \
					prereqs=prereqs, \
					coreqs=coreqs)
	for sec in sections:
		new_course.sections.add(sec)
	new_course.save()

def parseFile(file_name):
	global instructor_index
	global room_index
	global meeting_index
	global section_index

	# global output_file
	# global objects

	global rooms
	global instructors
	global meetings
	global sections
	global courses

	section_indexes = []
	ins_indexes = []
	meeting_indexes = []
	temp_ins_indexes = []
	temp_meeting_indexes = []

	# Step 1: parse the schedule file, get the courses
	schedule_file = open(file_name, 'r')
	schedule_content = schedule_file.read()
	parsed_schedule = json.loads(schedule_content)

	# item contains all courses from a department
	for item in parsed_schedule:
		# dept stores current department
		dept = item['department']
		print "department: %s" % (dept)

		# # TODO: remove it
		# if(dept != "Computer Science"):
		# 	continue
		# else:
		# 	print "department: %s" % (dept)

		# parse each course
		for course in item['courses']:

			print course["num"]
			
			# # TODO: remove it
			# if(int(course["num"]) > 15437):
			# 	break;

			section_indexes = []
			for lec in course['lectures']:
				# no sections 
				#     -> treat each lecture as a Section
				if(len(lec["sections"]) == 0):
					ins_indexes = []
					meeting_indexes = []
					# create a section according to the lecture data
					# 1. create instructors
					for ins_name in lec["instructors"]:
						saveInstructor(instructor_index, ins_name)
						instructor_index += 1
						ins_indexes.append(instructor_index)
					# 2. create rooms and meetings
					for meeting in lec["meetings"]:
						saveRoom(room_index, meeting["room"])
						room_index += 1
						# create meeting object
						new_meeting = saveMeeting(meeting_index, \
							ins_indexes, meeting["begin"], meeting["end"], \
							meeting["days"], room_index, meeting["location"])
						meeting_index += 1
						meeting_indexes.append(meeting_index)
					# 3. create section
					new_section = saveSection(section_index, \
						lec["lecture"], meeting_indexes)
					section_index += 1
					section_indexes.append(section_index)

				# multiple sections
				#     -> treat the combination of lec and 
				#        each section as a Section
				else:
					for section in lec["sections"]:
						ins_indexes = []
						meeting_indexes = []
						# create sections according to the lecture data
						# 1. create instructors
						for ins_name in lec["instructors"]:
							new_ins = saveInstructor(instructor_index, ins_name)
							instructor_index += 1
							ins_indexes.append(instructor_index)
						# 2. create rooms and meetings
						for meeting in lec["meetings"]:
							# create room object
							new_room = saveRoom(room_index, meeting["room"])
							room_index += 1
							# create meeting object
							new_meeting = saveMeeting(meeting_index, \
								ins_indexes, meeting["begin"], meeting["end"], \
								meeting["days"], room_index, meeting["location"])
							meeting_index += 1
							meeting_indexes.append(meeting_index)
						# 3. create sections
						# for section in lec["sections"]:
							temp_ins_indexes = []
							temp_meeting_indexes = []
							for i in meeting_indexes:
								temp_meeting_indexes.append(i)
							# 3.1. create instructors
							for ins_name in section["instructors"]:
								new_ins = saveInstructor(instructor_index, ins_name)
								instructor_index += 1
								temp_ins_indexes.append(instructor_index)
							# 3.2. create rooms and meetings
							for meeting in section["meetings"]:
								# create room object
								new_room = saveRoom(room_index, meeting["room"])
								room_index += 1
								# create meeting object
								new_meeting = saveMeeting(meeting_index, \
									temp_ins_indexes, meeting["begin"], meeting["end"], \
									meeting["days"], room_index, meeting["location"])
								meeting_index += 1
								temp_meeting_indexes.append(meeting_index)
							new_section = saveSection(section_index, \
								section["section"], temp_meeting_indexes)
							section_index += 1
							section_indexes.append(section_index)

			num = course["num"]
			# find the course description
			desc = findCourse(num)
			# not found
			if(desc == None):
				# no description found: leave some fields blank 
				# print "no description for course %s" % (num)
				saveCourse(num, \
						course["title"], \
						dept, \
						course["units"], \
						None, \
						None, \
						None, \
						None, \
						section_indexes)
			# found the course description
			else:
				# generate the new json object
				saveCourse(num, \
						desc["name"], \
						dept, \
						desc["units"], \
						desc["semester"], \
						desc["desc"], \
						desc["prereqs"], \
						desc["coreqs"], \
						section_indexes)

def matchInstructorName(name1, name2):
	# name1: "last name"
	# name2: "last name" + ", " + "capital of first name"
	#
	# To match name1 and name2, we need to compare the last name.
	# We'll also need to consider the following situation where
	# name2 equals to the prefix of name1, but they are not the
	# same person.
	#
	# Example:
	#     name1 = Ada, name2 = Adam
	#
	name1_upper = name1.upper() + ","
	name2_upper = name2.upper()
	count = 0
	for c in name1_upper:
		if c != name2_upper[count]:
			return False
		count = count + 1
	return True

# find and calculate the rating only according to the course id
# and the name of the instructor
def findRating(fces, course_id, instr_name):
	score = 0.0
	count = 0
	for item in fces:
		if(item["Course ID"] == course_id):
			year = item["Year"]
			# only count from 2011
			if(int(year) >= 2011):
				if(matchInstructorName(instr_name, item["Instructor"])):
					question = item["Questions"]
					if "9: Overall teaching" in question:
						overall = question["9: Overall teaching"]
					elif "28: Overall teaching" in question:
						overall = question["28: Overall teaching"]
					else:
						overall = None

					if(overall != "" and overall != None):
						count = int(count) + 1
						current_rating = float(overall)
						score = score + current_rating
					else:
						print overall
					# print float(question["9: Overall teaching"])
					# print "macth success: ", instr_name, ", ", item["Instructor"]
				# else:
				# 	print "macth failed: ", instr_name, ", ", item["Instructor"]
	if(count > 0):
		rating = score/count
		# print "Course: ", course_id, ", rating: ", rating
		return rating
	else:
		# print "Course: ", course_id, ", rating: ", 0.0
		return 0.0

def getAllRatings():
	# get fce data for all courses
	fce_file = open("./mercury/fixtures/course-api.json", 'r')
	content = fce_file.read()
	parsed_content = json.loads(content)
	fces = parsed_content["fces"]

	courses = Course.objects.all()
	for course in courses:
		course_id = course.id;
		print ""
		print "Course: ", course_id
		for section in course.sections.all():
			if section != None:
				sec_name = section.name
				print "Section: ", sec_name
				for meeting in section.meetings.all():
					# print "Meeting: ", meeting.begin, meeting.end, meeting.day, meeting.room.name, meeting.location
					for instructor in meeting.instructors.all():
						print "Instructor: ", instructor.name
						rating = findRating(fces, course_id, instructor.name)
						instructor.rating = float("{0:.2f}".format(rating))
						instructor.save()
						print "Rating: ", instructor.rating
	fce_file.close()

class Command(BaseCommand):
	help = 'runs your code in the django environment'

	def handle(self, *args, **options):
		parseFile("./mercury/fixtures/FallSchedule.json")
		getAllRatings()

