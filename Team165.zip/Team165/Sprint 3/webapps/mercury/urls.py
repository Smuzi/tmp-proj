from django.conf.urls import include, url

urlpatterns = [
    url(r'^$', 'mercury.views.home', name='home'),
    url(r'^login$', 'django.contrib.auth.views.login', {'template_name':'login.html'}, name='login'),
    url(r'^logout$', 'django.contrib.auth.views.logout_then_login', name='logout'),
    url(r'^register$', 'mercury.views.register', name='register'),
    url(r'^get_courses$', 'mercury.views.get_all_courses', name='get_all_courses'),
    url(r'^choose_course/(?P<course_id>\d+)$', 'mercury.views.choose_course'),
    url(r'^remove_choice/(?P<chosen_id>\d+)$', 'mercury.views.remove_choice'),
    url(r'^select_section/(?P<section_id>\d+)$', 'mercury.views.select_section_by_id'),
    url(r'^friends$', 'mercury.friends.friends', name='friends'),
    url(r'^send_request$', 'mercury.friends.friend_request', name='send_request'),
    url(r'^accept_request/(?P<username>\w+)$', 'mercury.friends.accept_request', name='accept_request'),
    url(r'^decline_request/(?P<username>\w+)$', 'mercury.friends.decline_request', name='decline_request'),
    url(r'^remove_friend/(?P<username>\w+)$', 'mercury.friends.remove_friend', name='remove_request'),
    url(r'^get_friends$', 'mercury.friends.get_friends', name='get_friends'),
    url(r'^see_schedule/(?P<username>\w+)$', 'mercury.friends.see_schedule', name='see_schedule'),
    url(r'^get_friends_courses/(?P<username>\w+)$', 'mercury.friends.get_friends_courses', name='get_friends_courses'),
	url(r'^course_search/(?P<search_text>\w+)$', 'mercury.views.course_search', name='course_search'),
	url(r'^search/', 'mercury.views.search', name='search'),
]
