from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.core.exceptions import ObjectDoesNotExist
from django.core import serializers
from django.http import HttpResponse
from django.db import transaction
import json
import datetime
from datetime import timedelta
import dateutil.parser as parser

# Decorator to use built-in authentication system
from django.contrib.auth.decorators import login_required

# Used to create and manually log in a user
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate

from mercury.models import *
from mercury.forms import *
from mercury.views import *



#------------------------------ 
#------------------------------ 

#get a list of all the potential meetings in schedule
#selected meetings + unselected ones (ignoring conflicts)
def get_all_meetings(user):
    #user = request.user
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    selected_meetings = schedule.meetings.all()
    selected_meetings = list(selected_meetings)
    for course in schedule.courses.all():
        for section in course.sections.all():
            for meeting in section.meetings.all():
                if not (meeting in selected_meetings):
                    selected_meetings.append(meeting)
    return selected_meetings
    
def get_selected_meetings(user):
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    return schedule.meetings.all()
	
#get a user and a specific section and returns whether or not all of the section meetings were selected in the schedule
def is_section_covered(user,section):
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    meetings = schedule.meetings.all()
    section_meetings = section.meetings.all()
    return set(section_meetings).issubset(set(meetings))


#get a user and check if the any of the sections in the course has been fully selected
def is_course_complete(user,course):
    for section in course.sections.all():
        if is_section_covered(user,section):
            return True #at least one of the sections is covered
    return False


#------------------------------ 
#returns False if meeting1 and meeting2 are not conflicting in time
#returns True otherwise
def meeting_conflict_oneToOne(meeting1,meeting2):
    if meeting1.day != meeting2.day:
        return False
    #both on same day:
    if meeting1.end <= meeting2.begin or meeting2.end<=meeting1.begin:
        return False
    return True


#does a single meeting conflict with a list of meetings
#return true if there is a conflict with at least one of the meetings in the list
def meeting_conflict_oneToMany(meeting1,meetingList):
    for meeting in meetingList:
        if meeting_conflict_oneToOne(meeting1,meeting):
            return True
    return False
        

#return True if there is a conflict between any of the meetings in either list
#returns False otherwise - no conflicts
def meeting_conflict_manyToMany(meetingList1,meetingList2):
    for meeting in meetingList1:
        if meeting_conflict_oneToMany(meeting,meetingList2):
            return True
    return False
#------------------------------ 



#returns True if a section is conflicted with any of the selected meetings
#assuming that a section is not selected already.
#if section is selected - will return TRUE - there is a conflict
def is_section_conflicting(user,section):
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    selected_meetings = schedule.meetings.all()
    #non_section_meetings = set(selected_meetings).difference(set(section.meetings.all())) #selected meetings excluding the ones actually from the section
    if meeting_conflict_manyToMany(selected_meetings,section.meetings.all()):
        return True
    return False


#get a course and return the meetings to display for that course
#if the course is complete - will return empty list
#otherwise, will return all available sections meetings
#courses that are complete will return empty list
def get_course_meetings(user,course):
    if is_course_complete(user,course):
        return []
    #student = Student.objects.get(user=user)
    #schedule = Schedule.objects.get(owner=student)
    #selected_meetings = schedule.meetings.all()
    course_meetings = []
    for section in course.sections.all():
        if not is_section_conflicting(user,section):
            course_meetings = course_meetings + section.meetings.all()
    return course_meetings


#get a list of all unselected meetings that are not conflicting with selected ones
def get_available_meetings(user):
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    available = []
    for course in schedule.courses.all():
        available = available + get_course_meetings(user,course)
    return available
            

#return True if a course cannot be completed - all the sections conflict
#returns False if at least one section is full
#UNDEFINED: course is already in selected meetings
def is_course_conflicting(user,course):
    for section in course.sections.all():
        if not is_section_conflicting(user,section):
            return False
    return True

def is_last_option(user,course):
	counter = 0
	for section in course.sections.all():
		if not is_section_conflicting(user,section):
			counter +=1
	if counter==1:
		return True
	return False
    
#------------------------------


#get a user and return all friends selected meetings
def get_friends_meetings(user):
    #user_meetings = get_all_meetings(user)
    user_student = Student.objects.get(user=user)
    meetings = set() #no empty set literal in python
    for friend in user_student.friends.all():
        friend_meetings = get_selected_meetings(friend.user)
        meetings = meetings.union(set(friend_meetings))
    return list(meetings)
        

#------------------------------ 
#receive a list of selected meetings and a section 
#returns all non-conflicting meetings in the section (even meetings that are already in the list)   
def get_available_meetings_in_section(section,meetingList):
    section_meetings = section.meetings.all()
    result = []
    for meeting in section_meetings:
        if not meetings_conflict_oneToMany(meeting,meetingList):
            result.append(meeting)
    return result

    
#receive a list of selected meetings and a course
#returns all non-conflicting meetings in the course (even meetings that are already in the list)    
def get_available_meetings_in_course(course,meetingList):
    result = []
    for section in course.sections.all():
        section_meetings = get_available_meetings_in_section(section,meetingList)
        result = result + section_meetings
    return result


#------------------------------
#get all sections that are the last option for the schedule 
def get_last_option_sections(user):
    last_sections = []
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    #get all the sections that are conflicting
    for course in schedule.courses.all():
        count = 0
        tmp_sections = []
        for section in course.sections.all():
            if not is_section_conflicting(user,section):
                tmp_sections.append(section)
                count +=1
        if count==1:
            last_sections = last_sections+tmp_sections
    return last_sections


#get all meetings that are last option for the schedule
def get_last_option_meetings(user):
    last_sections = get_last_option_sections(user)
    last_meetings = []
    for section in last_sections:
        for meeting in section.meetings.all():
            last_meetings.append(meeting)
    return last_meetings


#------------------------------

#assuming there is no conflict
def select_section(user,section):
    #section = Section.objects.get(pks=section_id)
    student = Student.objects.get(user=user)
    schedule = Schedule.objects.get(owner=student)
    for meeting in section.meetings.all():
        schedule.meetings.add(meeting)
	schedule.save()

def unselect_section(user,section):
	student = Student.objects.get(user=user)
	schedule = Schedule.objects.get(owner=student)
	selected_meetings = schedule.meetings.all()
	for meeting in section.meetings.all():
		if meeting in selected_meetings:
			schedule.meetings.remove(meeting)
	schedule.save()
	

