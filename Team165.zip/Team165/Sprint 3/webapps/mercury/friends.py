from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.core.exceptions import ObjectDoesNotExist
from django.core import serializers
from django.http import HttpResponse
from django.db import transaction
import json
import datetime
from datetime import timedelta
import dateutil.parser as parser

# Decorator to use built-in authentication system
from django.contrib.auth.decorators import login_required

# Used to create and manually log in a user
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate

from mercury.models import *
from mercury.forms import *
from mercury.views import *
# Create your views here.


def friends(request):
	context = {}
	context['form'] = friendRequestForm()
	current_student = Student.objects.get(user=request.user.id)
	context['friends_list'] = current_student.friends.all()
	context['friend_requests_list'] = current_student.friend_requestss.all()
	return render(request, 'friends.html', context)

def remove_friend(request,username):
	context = {}
	context['form'] = friendRequestForm()
	current_student = Student.objects.get(user=request.user)
	context['friends_list'] = current_student.friends.all()
	context['friend_requests_list'] = current_student.friend_requestss.all()
	user1 = request.user
	if User.objects.filter(username=username).exists():
		user2 = User.objects.get(username=username)
		student1 = Student.objects.get(user=user1)
		student2 = Student.objects.get(user=user2)
		if student1 in student2.friends.all():
			student2.friends.remove(student1)
		if student2 in student1.friends.all():
			student1.friends.remove(student2)
	return render(request, 'friends.html', context)
	

# friend_request sends a request from user 1 to user 2, 
# which adds these users to each other's request list
def friend_request(request):
	errors = []
	context = {}
	context['form'] = friendRequestForm()
	current_student =Student.objects.get(user=request.user)
	context['friends_list'] = current_student.friends.all()
	context['friend_requests_list'] = current_student.friend_requestss.all()
	user1 = request.user
	if not 'username' in request.POST or not request.POST['username']:
		errors.append('Username is required.')
		context['status'] = "Try again. Username is required."
		#context['errors'] = errors
		return render(request, 'friends.html', context)
	else:
		if User.objects.filter(username=request.POST['username']).exists():
			user2 = User.objects.get(username=request.POST['username'])
			student1 = Student.objects.get(user=user1)
			student2 = Student.objects.get(user=user2)
			## commented out because a request is not symmetric
			## list contains users who have sent a request
			## and are rendered in the notification list
			#student1.friend_requestss.add(student2)
			student2.friend_requestss.add(student1)
			#student1.save()
			student2.save()
			context['status'] = "Friend request sent."
			return render(request, 'friends.html', context)
		else: 
			errors.append('Username not found.')
			context['status'] = "Username not found."
			#context['errors'] = errors
			return render(request, 'friends.html', context)

#accept == true - accept request
#accept == false - decline request
def handle_request(request, student1,student2,accept=True):
	context = {}
	context['form'] = friendRequestForm()
	current_student =Student.objects.get(user=request.user)
	#if student1 in student2.friend_requestss.all():
	if student2 in student1.friend_requestss.all():
		student1.friend_requestss.remove(student2)
		student2.friend_requestss.remove(student1)
		if accept:
			student1.friends.add(student2)
			student2.friends.add(student1)
			context['notificationStatus'] = "You have accepted this request."
		student1.save()
		student2.save()
		context['friends_list'] = current_student.friends.all()
		context['friend_requests_list'] = current_student.friend_requestss.all()
		return render(request, 'friends.html', context)
	else:
		#error - shouldn't get here
		student2 = student2
		context['notificationStatus'] = 'Hold on. Something went wrong.'
		context['friends_list'] = current_student.friends.all()
		context['friend_requests_list'] = current_student.friend_requestss.all()
		return render(request, 'friends.html', context)
	#else:
		#context['notificationStatus'] = 'Hold on. Something went wrong.'
		#return render(request, 'friends.html', context)

def accept_request(request,username):
	user1 = request.user
	if User.objects.filter(username=username).exists():
		user2 = User.objects.get(username=username)
		student1 = Student.objects.get(user=user1)
		student2 = Student.objects.get(user=user2)
		return handle_request(request, student1,student2,True)
	else: 
		context['notificationStatus'] = 'Hold on. Something went wrong in accept request.'
		return render(request, 'friends.html', context)
		
def decline_request(request,username):
	user1 = request.user
	if User.objects.filter(username=username).exists():
		user2 = User.objects.get(username=username)
		student1 = Student.objects.get(user=user1)
		student2 = Student.objects.get(user=user2)
		return handle_request(request, student1,student2,False)
	else:
		context['notificationStatus'] = 'Hold on. Something went wrong in decline request.'
		return render(request, 'friends.html', context)


def get_friends(request):
	response_text = serializers.serialize("json", Student.objects.get(user=request.user))
	return HttpResponse(response_text, content_type="application/json")
			
def see_schedule(request, username):
	# Sets up list of just the logged-in user's friend's items
    context = {}
    wanted_user = User.objects.get(username=username)
    friend = Student.objects.get(user=wanted_user)
    schedule = Schedule.objects.get(owner=friend)
    context['friend']=username
    context['schedule'] = schedule

	#add last option and complete dict!!
    return render(request, 'friend-schedule.html', context)

def get_friends_courses(request, username):
    wanted_user = User.objects.get(username=username)
    friend = Student.objects.get(user=wanted_user)
    schedule = Schedule.objects.get(owner=friend)
    # retrieves all the courses that the student has selected on the right.
    course_list = schedule.courses.all()
    event_list = []
    selected_meetings = schedule.meetings.all()
    friend_meetings = get_friends_meetings(request.user)
    # goes through each of these courses
	
    for course in course_list:
        if is_course_complete(wanted_user,course):
            courseFlag = True 
        else:
            courseFlag = False
        section_list = course.sections.all() #
        for section in section_list: #
	        color = "#d3d3d3"
	        meeting_list = section.meetings.all()
	        for meeting in meeting_list:
	            displayFlag=False
	            if (meeting in selected_meetings):
	                color = "blue"
	                displayFlag=True
	                start = meeting.begin
	                end = meeting.end
	                if (meeting.day == "TBA"):
	                    break
	                else:
	                    for i in range(len(meeting.day)):
	                # weekday returns 0 for M, 1 for T, 2 for W...
	                        dayName= ""
	                        if (meeting.day[i] == "M"):
	                            dayName = "Monday, "
	                        if (meeting.day[i] == "T"): 
	                            dayName = "Tuesday, "
	                        if (meeting.day[i] == "W"): 
	                            dayName = "Wednesday, "
	                        if (meeting.day[i] == "R"): 
	                            dayName = "Thursday, "
	                        if (meeting.day[i] == "F"): 
	                            dayName = "Friday, "
	                        if (meeting.day[i] == "S"): 
	                            dayName = "Saturday, "
	                        if (meeting.day[i] == "U"): 
	                            dayName = "Sunday, "

	                    # create the class meeting event
	                        temp_event = {
	                            "title": course.name,
	                            #"start": datetime.combine(d, meeting.begin).isoformat("T"),
	                            "start": (parser.parse(dayName + str(start), fuzzy=True)).isoformat(),
	                            "end": (parser.parse(dayName + str(end), fuzzy=True)).isoformat(),
	                            "color": color,
	                            "course_number": course.id,
	                        }
	                        event_list.append(temp_event)
    return HttpResponse(json.dumps(event_list), content_type='application/json')
			
			
	
	