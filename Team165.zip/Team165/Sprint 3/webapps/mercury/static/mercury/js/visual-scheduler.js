var req;

// Sends a new request to update the visual scheduler.
function sendRequest() {
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
    } else {
        req = new ActiveXObject("Microsoft.XMLHTTP");
    }
    //console.log("sendRequest");
    req.onreadystatechange = handleResponse;
    // get what is currently on the visual scheduler
    // get the list of all the courses that the student has selected
        //schedule.courses is a field that has all the courses
    req.open("GET", "/mercury/get_courses", true);
    req.send(); 
}

// This function is called for each request readystatechange,
// and it will eventually parse the XML response for the request
function handleResponse() {
    if (req.readyState != 4 || req.status != 200) {
        return;
    }
    //console.log("handleResponse");
    // Removes the old visual scheduler items
    $('#calendar').fullCalendar('removeEvents');
    var meetings = JSON.parse(req.responseText);

    // Adds each new todo-list item to the list
    // Adds the events (courses) back to the calendar
    for (var i = 0; i < meetings.length; ++i) {
        // Extracts the item id and text from the response
        var title = meetings[i]["title"];
        var start = meetings[i]["start"];
        var end = meetings[i]["end"];
        var course_number = meetings[i]["course_number"];
        var color = meetings[i]["color"];
        var section_id = meetings[i]["section_id"];
        var temp_event = {
            "title": title,
            "start": start,
            "end": end,
            "color": color,
            "url": "/mercury/select_section/" + section_id
        };
        //console.log(temp_event);

        // Adds the course event to the calendar
        $('#calendar').fullCalendar('renderEvent', temp_event );
		
    }
}


window.onload = sendRequest;
