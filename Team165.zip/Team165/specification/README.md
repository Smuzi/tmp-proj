Turn in your project specification, and any related documents, to
this directory.
