Specification feedback
==================

**Team number**: 165<br>
**Team name**: Mercury <br>
**Team members**: congshal, usmadja, winniel

### Product Backlog (10/10)

### Data Models (10/10)

  * Looks okay. Be careful with having hard-baked validators (I believe if you're trying to schedule classes on a calendar enforcing a limit is sort of dumb. SIO doesn't until you register). 

  * Also, be careful with model validation. It's not a bad thing, but having your logic in multiple places (both Forms/ModelsForms and the Models) might cause you some issues if you don't coordinate on what you want as model validation and what you want as form validation.

### Wireframes or Mock-ups (10/10)

---
### Total Score (30/30)
---
Graded by: Andrew Zeng (azeng@andrew.cmu.edu)

---

To view this file with formatting, visit the following page: https://github.com/CMU-Web-Application-Development/Team165/blob/master/feedback/specification.md
