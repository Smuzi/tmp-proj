Project proposal feedback
==================

**Team number**: 165
**Team name**: Mercury
**Team members**: [congshal, usmadja, winniel]

### Andrew

You should consider integrating with existing libraries and APIs. Some examples might be using http://fullcalendar.io/ for your calendar functionality, and using the ScottyLabs Course API (https://scottylabs.org/course-api/). I think reducing your scope to only being for CMU will make your web app more feasable. Also, I don't that your goal of seeing when exams are is going to work since exam dates change all the time from semester to semeseter and aren't really set in stone ahead of time anyway. 

### Shuai

Your project idea is really practical and useful for students in school. Some of the features are not clearly explained though. You mentioned that users can see exam schedules, are they inputted by users or using some tools to automatically generate exam schedule for the class? You should more cleary define them in your project specification since it's a big difference considering complexity. Also, I want you to take one step further to extend your features more. For example, it would be cool if you can overlap several people's schedule and find out a common free time so that group project meeting times can be scheduled. 

### Brian

Look to [Schedule plus](http://scheduleplus.org/) for inspiration/ideas.  This will be heavy on the front-end, so research your options carefully.  There are many javascript calendar libraries.  I've had good experiences with http://fullcalendar.io/. It integrates nicely with jQuery.  Also http://momentjs.com/ is your friend for communicating dates between javascript and the back end.  For the back end, the export feature is a good idea since it requires integrating with an external API.  You have many good ideas for features, and the scope looks good for a 3 person team.



---

To view this file with formatting, visit the following page: https://github.com/CMU-Web-Application-Development/165/blob/master/feedback/proposal.md