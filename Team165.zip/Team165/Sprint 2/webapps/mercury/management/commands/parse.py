# import json
# import os
# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "webapps.settings")
# import django
# django.setup()

# # your imports, e.g. Django models
# from webapps.models import Location
# from mercury.models import *
# from mercury.forms import *

# course = Course.objects.filter(id=15437)
# print course.name

from django.core.management.base import BaseCommand
from mercury.models import *
import json

# class Command(BaseCommand):
# 	help = 'runs your code in the django environment'

# 	def handle(self, *args, **options):
# 		sec_file = open("../CourseInfo/section_init_data.json", 'r')
# 		content = sec_file.read()
# 		parsed_content = json.loads(content)

# 		sections = Section.objects.all()
# 		for section in sections:
# 			section.meetings = []
# 			for origin_section in parsed_content:
# 				pk = origin_section["pk"]
# 				if(int(pk) == section.id):
# 					fields = origin_section["fields"]
# 					meetings = fields["meetings"]
# 					print meetings
# 					for meeting in meetings:
# 						section.meetings.add(meeting)
# 					print section.meetings.all()
# 					section.save()
# 					break
# 		sec_file.close()

instructor_index = int(0)
room_index = int(0)
meeting_index = int(0)
section_index = int(0)

# objects = []
rooms = []
instructors = []
meetings = []
sections = []
courses = []

# search through CourseDescriptions.json, find the course
def findCourse(num):
	desc_file = open("../CourseInfo/CourseDescriptions.json", 'r')
	content = desc_file.read()
	parsed_content = json.loads(content)
	for course_desc in parsed_content:
		if course_desc["num"] == int(num):
			desc_file.close()
			return course_desc
	desc_file.close()
	return None

def saveInstructor(index, name):
	index = index + 1
	new_instructor = Instructor(id=int(index), name=name, rating=5.0)
	new_instructor.save()

def saveRoom(index, name):
	index = index + 1
	new_room = Room(id=int(index), name=name, rating=5.0)
	new_room.save()

def saveMeeting(index, instructors, begin, end, day, room, location):
	index = index + 1
	new_meeting = Meeting.objects.create(id=int(index), \
					begin=begin, \
					end=end, \
					day=day, \
					room_id=room, \
					location=location)
	for instr in instructors:
		new_meeting.instructors.add(instr)
	# new_meeting.instructors=instructors
	new_meeting.save()

def saveSection(index, name, meetings):
	index = index + 1
	new_section = Section.objects.create(id=int(index), \
					name=name)
	if(index in [172, 173, 174, 175]):
		print "original meetings", new_section.meetings.all()
		print "section id: ", new_section.id
		print "len of meetings: ", len(meetings)
    # TODO: figure out how to fix it
	while(len(new_section.meetings.all()) != 0):
	 	meeting = new_section.meetings.all()[0]
	 	new_section.meetings.remove(meeting)

	for meeting in meetings:
		m=Meeting.objects.get(id=meeting)
		new_section.meetings.add(m)
		new_section.save()

def saveCourse(num, name, department, units, semester, desc, prereqs, coreqs, sections):
	new_course = Course.objects.create(id=int(num), \
					name=name, \
					department=department, \
					units=units, \
					semester=semester, \
					desc=desc, \
					prereqs=prereqs, \
					coreqs=coreqs)
	for sec in sections:
		new_course.sections.add(sec)
	# new_course.sections = sections
	new_course.save()

def parseFile(file_name):
	global instructor_index
	global room_index
	global meeting_index
	global section_index

	# global output_file
	# global objects

	global rooms
	global instructors
	global meetings
	global sections
	global courses

	section_indexes = []
	ins_indexes = []
	meeting_indexes = []
	temp_ins_indexes = []
	temp_meeting_indexes = []


	# Step 1: parse the schedule file, get the courses
	schedule_file = open(file_name, 'r')
	schedule_content = schedule_file.read()
	parsed_schedule = json.loads(schedule_content)

	for item in parsed_schedule:
		# item contains all courses from a department
		# print "======\nitem: %s\n" % (item)

		# dept stores current department
		dept = item['department']
		
		if(dept != "Computer Science"):
			continue
		else:
			print "department: %s" % (dept)

		# parse each course
		for course in item['courses']:

			print course["num"]
			# TODO: remove it
			if(int(course["num"]) > 15437):
				break;

			section_indexes = []
			for lec in course['lectures']:
				# no sections 
				#     -> treat each lecture as a Section
				if(len(lec["sections"]) == 0):
					ins_indexes = []
					meeting_indexes = []
					# create a section according to the lecture data
					# 1. create instructors
					for ins_name in lec["instructors"]:
						saveInstructor(instructor_index, ins_name)
						instructor_index += 1
						ins_indexes.append(instructor_index)
					# 2. create rooms and meetings
					for meeting in lec["meetings"]:
						saveRoom(room_index, meeting["room"])
						room_index += 1
						# create meeting object
						new_meeting = saveMeeting(meeting_index, \
							ins_indexes, meeting["begin"], meeting["end"], \
							meeting["days"], room_index, meeting["location"])
						meeting_index += 1
						meeting_indexes.append(meeting_index)
					# 3. create section
					new_section = saveSection(section_index, \
						lec["lecture"], meeting_indexes)
					section_index += 1
					section_indexes.append(section_index)

				# multiple sections
				#     -> treat the combination of lec and 
				#        each section as a Section
				else:
					for section in lec["sections"]:
						ins_indexes = []
						meeting_indexes = []
						# create sections according to the lecture data
						# 1. create instructors
						for ins_name in lec["instructors"]:
							new_ins = saveInstructor(instructor_index, ins_name)
							instructor_index += 1
							ins_indexes.append(instructor_index)
						# 2. create rooms and meetings
						for meeting in lec["meetings"]:
							# create room object
							new_room = saveRoom(room_index, meeting["room"])
							room_index += 1
							# create meeting object
							new_meeting = saveMeeting(meeting_index, \
								ins_indexes, meeting["begin"], meeting["end"], \
								meeting["days"], room_index, meeting["location"])
							meeting_index += 1
							meeting_indexes.append(meeting_index)
						# 3. create sections
						# for section in lec["sections"]:
							temp_ins_indexes = []
							temp_meeting_indexes = []
							for i in meeting_indexes:
								temp_meeting_indexes.append(i)
							if(int(course["num"]) == 15104):
								print "init temp_meeting_indexes", temp_meeting_indexes
							# 3.1. create instructors
							for ins_name in section["instructors"]:
								new_ins = saveInstructor(instructor_index, ins_name)
								instructor_index += 1
								temp_ins_indexes.append(instructor_index)
							# 3.2. create rooms and meetings
							for meeting in section["meetings"]:
								# create room object
								new_room = saveRoom(room_index, meeting["room"])
								room_index += 1
								# create meeting object
								new_meeting = saveMeeting(meeting_index, \
									temp_ins_indexes, meeting["begin"], meeting["end"], \
									meeting["days"], room_index, meeting["location"])
								meeting_index += 1
								temp_meeting_indexes.append(meeting_index)
							new_section = saveSection(section_index, \
								section["section"], temp_meeting_indexes)
							if(int(course["num"]) == 15104):
								print "section: ", section["section"], "; final temp_meeting_indexes: ", temp_meeting_indexes
							section_index += 1
							section_indexes.append(section_index)

			num = course["num"]
			# print "course num: %s" % (num)
			# print "******\ncourse: %s" % (course)
			# find the course description
			desc = findCourse(num)
			# print "******\ncourse desc: %s\n" % (desc)
			if(int(num) == 15437):
				print section_indexes
			# not found
			if(desc == None):
				# no description found: leave some fields blank 
				# print "no description for course %s" % (num)
				saveCourse(num, \
						course["title"], \
						dept, \
						course["units"], \
						None, \
						None, \
						None, \
						None, \
						section_indexes)
			# found the course description
			else:
				# generate the new json object
				saveCourse(num, \
						desc["name"], \
						dept, \
						desc["units"], \
						desc["semester"], \
						desc["desc"], \
						desc["prereqs"], \
						desc["coreqs"], \
						section_indexes)

class Command(BaseCommand):
	help = 'runs your code in the django environment'

	def handle(self, *args, **options):
		parseFile("../CourseInfo/FallSchedule.json")

