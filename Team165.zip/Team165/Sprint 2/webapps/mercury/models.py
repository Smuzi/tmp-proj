from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator

# Instructor info
class Instructor(models.Model):
    name = models.CharField(max_length=50, blank=True, null=True)
    rating = models.FloatField(validators = [MinValueValidator(0.0), MaxValueValidator(5.0)], \
                               blank=True, 
                               null=True)
# Room info
class Room(models.Model):
    # name of the room, for example: BH A51
    name = models.CharField(max_length=50, blank=True, null=True)
    rating = models.FloatField(validators = [MinValueValidator(0.0), MaxValueValidator(5.0)], \
                               blank=True, 
                               null=True)

# student model: personal information, followees, schedule
class Student(models.Model):
    # user: username, first_name, last_name, email, etc
    user = models.ForeignKey(User)
    # friends: friends who shares their schedules with you
    friends = models.ManyToManyField('self', \
                                      related_name='friends', \
                                      symmetrical=True, \
                                      blank=True)
    friend_requestss = models.ManyToManyField('self', \
                                      related_name='friend_requests', \
                                      symmetrical=False, \
                                      blank=True)
	
# task: information of a task
#      - owner, subject, text, etc
class Task(models.Model):
    owner = models.ForeignKey(Student)
    subject = models.CharField(max_length=50, blank=True, null=True)
    number = models.IntegerField(blank=True, null=True)
    text = models.CharField(max_length=100, blank=True, null=True)
    duedate = models.DateTimeField(auto_now_add=False)

# Meeting model: time, date, room, location, etc
class Meeting(models.Model):
  # # Foreign key to section
  # section = models.ForeignKey(Section)
  # List of instructors of the section.
  instructors = models.ManyToManyField(Instructor, \
                                       related_name='instructors', \
                                       symmetrical=True, \
                                       blank=True)
  # The time at which the lecture or section begins.
  begin = models.CharField(max_length=50, blank=True, null=True)
  # The time at which the lecture or section ends.
  end = models.CharField(max_length=50, blank=True, null=True)
  # The day the lecture or section meets.
  day = models.CharField(max_length=50, blank=True, null=True)
  # The building and/or room in which the lecture meets.
  room = models.ForeignKey(Room)
  # The location of the lecture. For example, "Pittsburgh, Pennsylvania".
  location = models.CharField(max_length=200, blank=True, null=True)

# section model: information of the section
class Section(models.Model):
    # # Foreign key to course
    # course = models.ForeignKey(Course)
    # The section's identifier. Almost always a capital letter.
    name = models.CharField(max_length=50, blank=True, null=True)
    # List of meetings for the sections.
    meetings = models.ManyToManyField(Meeting, \
                                      related_name='meetings', \
                                      symmetrical=True, \
                                      blank=True)

# course model: course info, course status
# NEED: course_number as field in course (see choose_course)
class Course(models.Model):
    # name: course name
    name = models.CharField(max_length=50, blank=True, null=True)
    # Department name
    department = models.CharField(max_length=200, blank=True, null=True)
    # Units awarded by course: min 0.0, max 50.0
    # might need to use IntegerField
    # units = models.FloatField(validators = [MinValueValidator(0.0), MaxValueValidator(50.0)], \
    #                           blank=True, \
    #                           null=True)
    units = models.CharField(max_length=20, blank=True, null=True)
    # List of semesters where the course is offered ("F" = Fall, "S" = Spring, "M" = Summer)
    # Format might be: [F, S]
    semester = models.CharField(max_length=50, blank=True, null=True)
    # Course description
    desc = models.CharField(max_length=500, blank=True, null=True)
    # Course prerequisites as a string
    prereqs    = models.CharField(max_length=500, blank=True, null=True)
    # Course core quisites as a string
    coreqs = models.CharField(max_length=500, blank=True, null=True)
    # Sections for this semester.
    sections = models.ManyToManyField(Section, \
                                      related_name='lectures', \
                                      symmetrical=False, \
                                      blank=True)
    # All historical FCEs, organized by section.
    # fces = models.ManyToManyField(FCE, \
    #                               related_name='FCEs', \
    #                               symmetrical=False, \
    #                               blank=True, \
    #                               null=True)

# schedule model: owner, courses
class Schedule(models.Model):
    # owner: student that owns the schedule
    owner = models.ForeignKey(Student)
    # courses: courses that are on the list but NOT selected
    courses = models.ManyToManyField(Course, \
                                     related_name='courses', \
                                     symmetrical=False, \
                                     blank=True)
    # meetings: selected meetings
    meetings = models.ManyToManyField(Meeting, \
                                      related_name='selectedMeetings', \
                                      symmetrical=False, \
                                      blank=True)