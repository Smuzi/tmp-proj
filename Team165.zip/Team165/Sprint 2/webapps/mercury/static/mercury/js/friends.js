var req;

// Sends a new request to update the visual scheduler.
function sendRequest() {
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
    } else {
        req = new ActiveXObject("Microsoft.XMLHTTP");
    }
    //console.log("sendRequest");
    req.onreadystatechange = handleResponse;
    // get what is currently on the visual scheduler
    // get the list of all the courses that the student has selected
        //schedule.courses is a field that has all the courses
    req.open("GET", "/mercury/get_friends", true);
    req.send(); 
}

// This function is called for each request readystatechange,
// and it will eventually parse the XML response for the request
function handleResponse() {
    if (req.readyState != 4 || req.status != 200) {
        return;
    }
    //console.log("handleResponse");
    // Removes the friends list items
    var friendsList = document.getElementById("friends-list");
    while (friendsList.hasChildNodes()) {
        friendsList.removeChild(friendsList.firstChild);
    }

    // Removes the notification list items
    var notificationsList = document.getElementById("notifications-list");
    while (notificationsList.hasChildNodes()) {
        notificationList.removeChild(notificationList.firstChild);
    }

    var student = JSON.parse(req.responseText);
    friendsList = student[]

    // Adds each new todo-list item to the list
    for (var i = 0; i < .length; ++i) {
        // Extracts the item id and text from the response
        var id = items[i]["pk"];  // pk is "primary key", the id
        var itemText = items[i]["fields"]["text"];
  
        // Builds a new HTML list item for the todo-list item
        var newItem = document.createElement("li");
        newItem.innerHTML = "<a href=\"/shared-todo-list/delete-item/" + id + "\">X</a> " + itemText;

        // Adds the todo-list item to the HTML list
        list.appendChild(newItem);
    }


    // Adds the events (courses) back to the calendar
    for (var i = 0; i < meetings.length; ++i) {
        // Extracts the item id and text from the response
        var title = meetings[i]["title"];
        var start = meetings[i]["start"];
        var end = meetings[i]["end"]
        var course_number = meetings[i]["course_number"]
        var color = meetings[i]["color"]
        var section_id = meetings[i]["section_id"]
        var temp_event = {
            "title": title,
            "start": start,
            "end": end,
            "color": color,
            "url": "/mercury/select_section/" + section_id
        }
        //console.log(temp_event);

        // Adds the course event to the calendar
        $('#calendar').fullCalendar('renderEvent', temp_event )
    }
}

// causes the sendRequest function to run every 10 seconds
window.setInterval(sendRequest, 10000);
